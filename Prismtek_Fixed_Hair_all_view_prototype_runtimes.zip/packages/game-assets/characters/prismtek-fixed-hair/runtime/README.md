Prismtek Fixed Hair all-view prototype runtimes.

Views included: low_top_down, top_down, isometric, profile_lobby.
These are prototype/playtest outputs; Pixelorama cleanup is still required for final limb motion.
