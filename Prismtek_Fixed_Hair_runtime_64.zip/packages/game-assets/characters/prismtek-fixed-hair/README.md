# Prismtek Fixed Hair — Game-Ready Animation Pack v2

This is the cleaned, game-ingestible pack. It includes transparent frames, strips, GIF previews, and atlas manifests for every allowed Prismcade size.

Default runtime size: 64x64.

Each size folder contains:

```txt
runtime/<size>/
  frames/<slot>/*.png
  strips/<slot>_<size>.png
  gifs/<slot>_<size>.gif
  atlas/atlas.png
  manifest.json
```

Rows with props/effects are marked with `containsProp: true`.


## Split package note

This zip contains only the `64x64` runtime folder.

Copy this package into the repository root, preserving paths:

```txt
packages/game-assets/characters/prismtek-fixed-hair/
  manifest.prismcade-character.json
  runtime/64/
```

Upload the other size zips separately if you want the repo to include every generated runtime size.
