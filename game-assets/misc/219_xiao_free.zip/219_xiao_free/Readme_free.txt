🦉 219_Xiao_free - Sample Animation Assets

This is the free version of the "Xiao" owl-type enemy character animation pack.  
It includes a small but functional set of sprite images for use in prototyping or lightweight projects.
------------------------------------
📁 Included Files:
------------------------------------
- idle_front_01.png
- idle_back_01.png
- move_01.png
- move_02.png
- move_03.png
- hit_01.png
- hit_02.png
- hit_03.png (includes visual FX)
- die_01.png
- die_02.png
- die_03.png (burn effect)
- die_04.png (explosion effect)

------------------------------------
🧠 Technical Note (Creation Process)
------------------------------------
All assets in this pack are created through a human–AI collaboration workflow.

All visual materials were generated using **text-to-image prompts** via **OpenAI's DALL·E**,  
without uploading or referencing any existing images.  
They were then manually **cropped, renamed, sequenced, and refined** by the creator to ensure consistent animation logic.

------------------------------------
🎯 Recommended Use:
------------------------------------
- Game engine testing
- Prototype enemies
- Free demos or student projects
- Evaluation before purchasing the full pack

------------------------------------
⚠️ License:
------------------------------------
This free version is for **non-commercial use only**.  
For commercial licensing or full-feature content (attack animations, special effects, sound FX, complete animation sequences), please purchase the Standard version.

------------------------------------
🛠️ Notes:
------------------------------------
- All sprites are transparent PNGs (256x256)
- Pixel-art style, consistent character shading and proportions
- No AI training allowed on this content (See full license in Standard pack)

Created by Lucky Luck Studio (2025)
