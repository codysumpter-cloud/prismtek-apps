# Buddy System Repository Map — GPT Knowledge File

This file is a concise, GPT-loadable map of the Buddy / Prismtek ecosystem. It is context, not proof of current build, CI, release, or live deployment status. For current claims, inspect the live repo state.

## Core Rule

Do not collapse the Buddy ecosystem into one repo. Each repo owns a different layer.

## Repository Authority Order

For Buddy/Prismtek-specific work, prefer this order unless the task clearly belongs to a narrower repo:

1. `knowledge-vault`
2. `buddy-brain`
3. `buddy-agent`
4. `omni-buddy`
5. `prismtek-apps`

`buddy-universal-agent-profile` defines the portable Buddy/Lil’ Buddy behavior standard across tools.

## Repositories

### knowledge-vault

Role: durable operating memory, agent-readable knowledge database, project book, decisions, status, roadmaps, runbooks, handoffs, graph records, event history, and Vegapunk Brain / Punk Records shared-memory layer.

Use it for terminology, roadmap, project memory, historical decisions, source-of-truth questions, Vegapunk Brain / Punk Records, context bundles, and agent-facing operating rules.

Important boundary: GitHub repo state remains the source of truth for code, issues, pull requests, CI, and releases. KnowledgeVault is public; do not store private credentials or private workspace details there.

### buddy-brain

Role: operator brain, policy layer, council memory, posture, runbooks, skills registry, cross-repo coordination, and operator contracts.

Use it for governance, policy, council roles, operating posture, agent contracts, runbooks, skills registry, cross-repo coordination, and durable operator continuity.

Important boundary: It is not the iPhone app, public website, or Telegram host runtime by itself. It does not prove live fixes in product/runtime surfaces unless the owning path was changed and validated.

### buddy-agent

Role: guarded execution layer and local companion/runtime package for Prismtek’s Agentic OS. It connects runtime shell, skills, memory, policies, adapters, and receipts behind conservative defaults.

Use it for CLI/runtime execution, local/offline execution defaults, skills and skill manifests, provider policies, receipts, adapters, local memory, runtime shell, and app/runtime integration contracts.

Important boundary: Current public posture is alpha/runnable-alpha, not finished autonomous production operator. Defaults are local/offline/manual approval. Bridges to KnowledgeVault, Buddy Brain, Omni, and apps are contract/future-work unless audited in implementation.

### omni-buddy

Role: Raspberry Pi / local multimodal agent runtime path: wake word, speech-to-text, local LLM, text-to-speech, reactive face animations, camera/vision, mesh/transport experiments, and device-focused runtime.

Use it for Raspberry Pi, wake word, voice, local/offline models, Ollama, Whisper.cpp, Piper TTS, camera/vision, local hardware, mesh/Reticulum transport, and embodied/device runtime.

Important boundary: Hardware support must be verified on the target device. Local scripts/docs are not proof that a specific Pi/device deployment is currently working.

### prismtek-apps

Role: runnable product workspace for Prismtek products: mobile apps, desktop apps, web apps, games, tools, services, demos, and shipped product surfaces.

Use it for iOS/macOS apps, BeMore product UX, web apps, games, Pixel Fruit Arena, product APIs, user-facing product features, and product build/release readiness.

Important boundary: It does not own the core runtime substrate, governance, durable memory, or Buddy Brain policy layer. Some entries may be source/playable MVPs while packaged release artifacts remain pending; verify per product.

### buddy-universal-agent-profile

Role: BUAP — portable behavior/orchestration standard for Buddy and Lil’ Buddy across tools.

Use it for how this GPT should behave, Buddy/Lil’ Buddy role split, orchestration loop, response format, validation discipline, repo-discovery standards, and cross-tool agent profile setup.

Important boundary: BUAP does not spawn sub-agent processes by itself. If no real sub-agent runtime exists, Lil’ Buddy is an emulated workflow phase.

## Conflict Handling

When repo claims conflict:
1. Prefer current implementation over docs.
2. Prefer the owning repo for the surface involved.
3. Prefer KnowledgeVault for durable memory/terminology, but not for live code/CI/release claims.
4. Prefer Buddy Brain for governance and policy, but not for product/runtime live behavior.
5. Mark unresolved conflicts as unknown and recommend verification.

## Required Anti-Duplication Check

Before proposing a new system, workflow, memory layer, agent loop, runtime path, config source, or bridge:

1. Check whether an existing repo already owns that responsibility.
2. If yes, extend that repo/system.
3. If no, state where you looked and why a new component is justified.
