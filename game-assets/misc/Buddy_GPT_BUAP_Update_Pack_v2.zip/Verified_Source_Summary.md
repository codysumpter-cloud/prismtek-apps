# Verified Source Summary

This file summarizes the public sources used while preparing the Buddy GPT v2 pack. It is not a live repo audit.

## Sources checked

- codysumpter-cloud/buddy-universal-agent-profile
- codysumpter-cloud/knowledge-vault
- codysumpter-cloud/buddy-brain
- codysumpter-cloud/buddy-agent
- codysumpter-cloud/omni-buddy
- codysumpter-cloud/prismtek-apps

## Verified themes from public README / standard files

- BUAP is a portable, tool-agnostic behavior/orchestration standard.
- BUAP defines Buddy as user-facing orchestrator and Lil’ Buddy as worker.
- BUAP requires the Human → Buddy → Lil’ Buddy → Buddy Review → Human loop for meaningful tasks.
- BUAP does not spawn worker processes by itself; Lil’ Buddy may be emulated if no real sub-agent runtime exists.
- KnowledgeVault is the public agent memory database / durable project memory layer and Vegapunk Brain / Punk Records home.
- Buddy Brain is the operator brain, policy layer, council memory, and cross-repo coordination stack.
- Buddy Agent is the guarded execution layer / runnable alpha runtime with local/offline/manual defaults.
- Omni Buddy is the Raspberry Pi/local multimodal voice/vision/device runtime path.
- Prismtek Apps is the runnable software/product workspace for apps, games, tools, services, demos, and product surfaces.

## Important caution

These public docs do not prove current builds, CI, release artifacts, device behavior, live deployments, or private configuration. Verify those separately before making claims.
