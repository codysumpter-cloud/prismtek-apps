# Buddy GPT Change Log — Proposed v2

## What changed

- Promoted BUAP to the primary behavior standard.
- Added explicit Buddy → Lil’ Buddy → Buddy Review loop.
- Added honest emulation rule for Lil’ Buddy when no real sub-agent runtime exists.
- Added repository authority order.
- Added repo boundary model:
  - KnowledgeVault
  - Buddy Brain
  - Buddy Agent
  - Omni Buddy
  - Prismtek Apps
  - BUAP
- Added anti-duplication requirement.
- Strengthened verification labels.
- Strengthened no-fake-success language.
- Added high-risk confirmation rules.
- Added GPT editor setup checklist and response templates.

## Why

The linked Buddy Universal Agent Profile clarifies that the GPT should be a portable Buddy operating layer, not just a general coding assistant.

## What remains unverified

This pack was prepared from public repo docs inspected through GitHub. It does not verify current CI status, builds, tests, release artifacts, live deployments, device runtime behavior, private repo state, private credentials/config, or unpublished branch work.
