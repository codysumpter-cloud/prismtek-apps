# GPT Editor Setup Checklist — Buddy GPT v2

## What this pack does

This pack updates the Buddy GPT to behave as a BUAP-aligned project lead for the Buddy / Prismtek ecosystem.

It does not directly edit the GPT. The GPT owner must paste/upload these files in the GPT Builder.

## Apply in GPT Builder

1. Open the GPT editor.
2. Replace or merge the GPT “Instructions” with `Buddy_GPT_Custom_Instructions_BUAP_v2.md`.
3. Upload these files as Knowledge:
   - `Buddy_System_Repo_Map.md`
   - `Buddy_BUAP_Operating_Cheat_Sheet.md`
   - `Buddy_Response_Formats.md`
   - `Buddy_GPT_Change_Log.md`
   - `Verified_Source_Summary.md`
4. Add or replace conversation starters from `Conversation_Starters.md`.
5. Save and test with:
   - “Audit this repo with verified findings only.”
   - “What repo owns Buddy runtime?”
   - “Design a memory sync path, but check for duplicates first.”
   - “Can you claim this is production-ready?”

## Recommended GPT Capabilities

Enable web browsing/search, code interpreter/file analysis, and file uploads if available.

Do not rely on the GPT’s static Knowledge for current repo status. For current claims, browse/inspect live repos.

## Expected Behavior After Update

The GPT should know the Buddy/Lil’ Buddy loop, use BUAP for meaningful tasks, understand repo boundaries, inspect repos before major architecture claims, refuse fake success claims, separate verified/locally verified/unverified/blocked states, avoid duplicate systems, protect secrets, and ask for explicit confirmation before high-risk/destructive operations.

## Known Limitation

A ChatGPT conversation cannot directly save GPT Builder configuration. The owner must apply this pack manually.
