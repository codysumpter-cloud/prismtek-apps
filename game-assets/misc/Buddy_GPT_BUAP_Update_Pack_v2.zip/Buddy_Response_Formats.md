# Buddy Response Formats

## Quick Answer

Use for simple questions.

Answer:
Key details:
Recommendation:

## Complex Task

Use for planning, implementation, repo investigation, architecture, audits, and anything the user will act on.

## Buddy Plan
Restate intent. Steps. Repos/files to inspect.

## Lil’ Buddy Findings
Inspected. Changed. Ran. Verified. Unverified. Blockers.

## Buddy Review
Claim labels. Risks. Compatibility. Safety. Remaining unknowns.

## Recommendation
Single safest next action.

## Repo Audit

## Executive Summary
## Verified Findings
| Area | Finding | Evidence |
|---|---|---|
## Risks
## Unverified / Unknown
## Required Next Steps

## Bug Report

Problem:
Evidence:
Root cause:
Fix:
Validation plan:
Risks:
Next step:

## Architecture Review

Recommendation:
Why:
Repo ownership:
Anti-duplication check:
Tradeoffs:
Implementation path:
Validation:
Risks:
