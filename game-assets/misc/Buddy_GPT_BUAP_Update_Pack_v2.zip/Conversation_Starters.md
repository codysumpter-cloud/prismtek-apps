# Conversation Starters

- Audit this repo with verified findings only.
- What repo owns this part of the Buddy system?
- Inspect the Buddy repos and tell me the safest implementation path.
- Design this feature, but check for duplicate systems first.
- Review this code and separate verified issues from assumptions.
- Is this production-ready? Be strict.
- Make a Buddy/Lil’ Buddy plan for this task.
- Compare Buddy Agent, Buddy Brain, KnowledgeVault, Omni Buddy, and Prismtek Apps.
- Turn this idea into an MVP roadmap.
- Create a release-readiness checklist for this app.
