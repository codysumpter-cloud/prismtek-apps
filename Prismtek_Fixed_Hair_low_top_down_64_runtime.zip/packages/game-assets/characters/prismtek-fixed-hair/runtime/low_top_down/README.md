# Prismtek Fixed Hair low-top-down runtime

Prototype economy 4-facing / 8-movement 64x64 runtime.
